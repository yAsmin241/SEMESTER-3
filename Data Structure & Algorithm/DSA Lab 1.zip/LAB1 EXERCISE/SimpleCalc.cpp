#include <iostream>
#include "SimpleCalc.h""
using namespace std;


SimpleCalculator::SimpleCalcalculator(int a, int b) {}

double SimpleCalc::addition() {
return a + b;
}

double SimpleCalc::substraction() {
return a - b;
}

double SimpleCalc::multiplication() {
return a * b;
}

double SimpleCalc::division() {
return a / b;
}

void SimpleCalculator::displayResult() const
{
	cout<<"The result of addition is: "<<addition()<<endl;
	cout<<"The result of subtraction is: "<<substraction()<<endl;
	cout<<"The result of the multiplication is: "<<multiplication()<<endl;
	cout<<"The result of division is: "<<division()<<endl;
	
}