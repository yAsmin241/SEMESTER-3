//const int a = 10;
//const int b = 2;

class  SimpleCalculator 
{
public:
//	SimpleCalculator ();
//	SimpleCalculator (int b);
	int addition(int,int)const;
	int substraction() const;
	int multiple() const;
	int division() const;
	void displayResult() const;
	
//private:
//	int a;	
//	int b;
};