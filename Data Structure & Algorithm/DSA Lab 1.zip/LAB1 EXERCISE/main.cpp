#include <iostream>
#include <conio.h>
#include "SimpleCalc.h"
using namespace std;

int main (){
	int a = 10;
	int b = 2;
	
	SimpleCalculator calculator (a,b);
	
	calculator.displayResult();
	
	return 0;
}